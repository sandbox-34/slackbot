# Welcome to Slackbot

Make sure to save your Slack API token in the "Secrets" section of the Github repository settings.